import React, { useState } from 'react';
import './App.css';
function App() {
  const [inputValue, setInputValue] = useState('');
  const [stars, setStars] = useState([]); 

  const handleChange = (event) => {
    setInputValue(event.target.value);
  };

  
  const handleSubmit = (event) => {
    event.preventDefault(); 
    const count = parseInt(inputValue, 10);
    if (!isNaN(count) && count > 0) {
      let starsArray = []
      for (let i = 0; i < count; i++) {
        starsArray.push('*'.repeat(i));
      }
      for (let i = count; i >= 1; i--) {
        starsArray.push('*'.repeat(i));
      }
      setStars(starsArray);
    } else {
      setStars([]);
    }
  };

  return (
    <div className="App">
      <h1>Star Display</h1>
      <form onSubmit={handleSubmit}>
        <input
          type="number"
          value={inputValue}
          onChange={handleChange}
          min="1"
          placeholder="Enter a number"
        />
        <t> </t>
        <button type="submit">Submit</button>
      </form>
      <div>
        {stars.map((line, index) => (
          <div key={index}>{line}</div>
        ))}
      </div>
    </div>
  );
}

export default App;

