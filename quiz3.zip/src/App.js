import React from 'react';
import ProfilePic from './Profile2.png';
import LinkedIn from './LinkedIn.png';
import Github from './github.jpg';
// import React, { useState, useEffect } from 'react';
import './App.css';
const CV = () => {
  return (
    <div className="cv-container">
      {/* Header */}
      <header className="cv-header">
         
        <div class = "grid-container1">
          <div><img className="cv-profile-pic" src={ProfilePic} alt="Profile" /></div>
          <div className="header-info">
            <h3>Kantapat Thienthanawint</h3>
            <p>Bangkok/ Thailand | 098 295 5655</p>
            <p> ponds111@gmail.com</p>
            <p>
              <a href="https://www.linkedin.com/in/CappucinaXz/" className="cv-link"><img className="Linkedin" src={LinkedIn} alt="LinkedIn" />LinkedIn </a>
              <t> | </t>
              <a href="https://github.com/CappucinaXZ" className="cv-link"><img className="Github" src={Github} alt="Github" />GitHub</a>
            </p>
            <p> <a href="https://github.com/CappucinaXZ" className="cv-link">https://github.com/CappucinaXZ</a></p>
            <p> <a href="https://www.linkedin.com/in/CappucinaXz/" className="cv-link">https://www.linkedin.com/in/CappucinaXz/</a></p>
          </div>
        </div>
      </header>

      {/* Education Section */}
      <section className="cv-section">
        <div>
          <h3 className='topic'>Education_________________________________________________________________________________________________________________________________</h3>
        </div>
        
        <div className="grid-container2">
          <div><h2>   Watrajabopit School</h2></div>
          <div><p className='date'>2013 - 2019</p></div>  
        </div>
        <p >Gifted Gen 2</p>
        <div className="grid-container2">
          <h2>Mahidol University</h2>
          <div><p className='date'>2019 - 2023</p></div>  
        </div>
        <p >Bachelor of Computer Engineering</p>
      </section>

      {/* Coursework Section */}
      <section className="cv-section">
        <h3 className='topic'>Coursework_________________________________________________________________________________________________________________________________</h3>
        <div className="cv-coursework">
          <div>• Object Oriented Programming</div>
          <div>• Computer Network</div>
          <div>• Software Engineering</div>
          <div>• Database Systems</div>
          <div>• Data Structures & Algorithms</div>
          <div>• Microprocessor & Interfacing</div>
          <div>• Operating Systems</div>
          <div>• Penetration Testing & Prevention</div>
          <div>• Software Reverse Engineering</div>
          <div>• Web Programming</div>
          <div>• Big Data Processing</div>
          <div>• Digital Forensics</div>
        </div>
      </section>

      {/* Projects Section */}
      <section className="cv-section">
        <h3 className='topic'>Projects_______________________________________________________________________________________________________________________________</h3>
        <div className="cv-project">
        <div className="grid-container2">
          <div>
            <h3>
              <a href="https://github.com/CappucinaXZ/Escape_Room" className="cv-link">
                Escape_Room
              </a>
            </h3>
          </div> 
          <div className='date'>Dec 2020</div>
        </div>
        <p>A survivor game where the main character solves problems to escape from a house.</p>
      </div>
      <div className="cv-project">
        <div className="grid-container2">
          <div>
            <h3>
              <a href="https://github.com/CappucinaXZ/Tram_tracking_draft" className="cv-link">
                Tramer - Tram Tracker 
              </a>
            </h3>
          </div> 
          <div className='date'>Dec 2021</div>
        </div>
        <p>Designed the front-end and back-end for a tram tracking application.</p>
      </div>
      <div className="cv-project">
        <div className="grid-container2">
          <div>
            <h3>
              <a href="https://github.com/CappucinaXZ/Sheetshare3" className="cv-link">
                Sheetshare 
              </a>
            </h3>
          </div> 
          <div className='date'>Arp 2023</div>
        </div>
        <p>Designed the front-end and back-end for a web application.</p>
      </div>
      </section>

      {/* Skills Section */}
      <section className="cv-section">
        <h3 className='topic'>Skills___________________________________________________________________________________________________________________________________</h3>
        <div className="cv-skills">
        <div className="grid-container2">
          <div><h3>Programming Languages</h3></div>
          <div classname ="top"><p>Python | C | C++ | Java | Assembly | Linux Command | Golang | JavaScript</p></div>
          </div>
        </div>
        <div className="cv-skills">
          <div className="grid-container2">
            <div><h3>Languages</h3></div>
            <div><p>Thai (Native), English (Intermediate), Japanese (Basic)</p></div>
          </div>
        </div>
        <div className="cv-skills">
        <div className="grid-container2">
          <div><h3>Software & Tools</h3></div>
          <div>
            <p>CodeBlocks | Apache NetBeans | Visual Studio | VirtualBox | Kali | Microchip Studio | Google Cloud | AWS | Docker | Kubernetes | PuTTY | vite&vue  | react</p>
          </div>
        </div>
          <h3></h3>
          
        </div>
      </section>

      {/* Experience Section */}
      <section className="cv-section">
        <h3 className='topic'>Training_________________________________________________________________________________________________________________________________</h3>
        <ul className="cv-bullets">
          <li>• Cybersecurity Boot Camp 2021</li>
          <li>• Cyber Secroom Infosec</li>
          <li>• FutureSkill: DevOps Engineer Course</li>
          <li>• FutureSkill: Full Stack Engineer & Golang Course</li>
        </ul>
      </section>

      <section className="cv-section">
        <h3 className='topic'>Internship_________________________________________________________________________________________________________________________________</h3>
        <p>• MFEC Information Security Intern (Jul 2022 - Nov 2022)</p>
      </section>

      {/* Activities Section */}
      <section className="cv-section">
        <h3 className='topic'>Activities_________________________________________________________________________________________________________________________________</h3>
        <ul className="cv-bullets">
          <li>• Staff at CrickCamp 2020</li>
          <li>• Work & Travel in the USA (May 2023 - Sep 2023)</li>
        </ul>
      </section>
    </div>
  );
};

export default CV;
